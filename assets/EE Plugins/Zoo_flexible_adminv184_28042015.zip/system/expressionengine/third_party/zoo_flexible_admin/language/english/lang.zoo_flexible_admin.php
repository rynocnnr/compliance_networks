<?php
$lang = array(

"zoo_flexible_admin_module_name" 			=> 'Zoo Flexible Admin',
"zoo_flexible_admin_module_description" 	=> 'Create custom control panel menus per membergroup', 
"Zoo_flexible_admin" 			=> 'Zoo Flexible Admin',
//
''=>''
);