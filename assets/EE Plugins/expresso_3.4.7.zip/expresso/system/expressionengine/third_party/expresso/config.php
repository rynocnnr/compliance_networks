<?php
// define add-on constants
define('EXPRESSO_NAME', 'Expresso');
define('EXPRESSO_SHORT_NAME', 'expresso');
define('EXPRESSO_DESCRIPTION', 'Expresso provides you with a WYSIWYG editor fieldtype for channel entries.');
define('EXPRESSO_AUTHOR', 'Ben Croker');
define('EXPRESSO_VERSION', '3.4.7');
define('EXPRESSO_URL', 'http://www.putyourlightson.net/expresso');
// END
