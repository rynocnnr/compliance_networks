<?php

$lang = array(

"license_number" =>
"License Number",

"valid_license" =>
"Valid License",

"invalid_license" =>
"Invalid license number",

"global_settings" =>
"Global Settings",

"headers" =>
"Header Styles",

"startupOutlineBlocks" =>
"Outline Blocks by Default",

"entities_additional" =>
"Additional Entities to Escape",

"toolbar_icons" =>
"Toolbar Icons",

"contentsCss" =>
"CSS",

"toolbar" =>
"Toolbar",

"file_manager" =>
"File Manager",

"forcePasteAsPlainText" =>
"Force Paste As Plain Text",

"toolbarCanCollapse" =>
"Toolbar Can Collapse",

"custom_toolbar" =>
"Custom Toolbar",

"add_sample_code" =>
"Add Sample Code",

"styles" =>
"Styles",

"export_settings" =>
"Export Settings",

"import_settings" =>
"Import Settings",

"import" =>
"Import",

"or" =>
"or",

"close" =>
"Close",

"import_settings_error" =>
"There was an error importing your settings. Please ensure that you copied and pasted them exactly as they were exported.",

''=>''
);

/* End of file lang.expresso.php */
/* Location: ./system/expressionengine/third_party/expresso/language/english/lang.expresso.php */
