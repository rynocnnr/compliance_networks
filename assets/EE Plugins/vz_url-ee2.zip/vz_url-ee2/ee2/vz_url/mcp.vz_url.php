<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * VZ URL Module Control Panel
 *
 * @author    Eli Van Zoeren <eli@elivz.com>
 * @copyright Copyright (c) 2010-2015 Eli Van Zoeren
 * @license   http://creativecommons.org/licenses/by-sa/3.0/ Attribution-Share Alike 3.0 Unported
 */

class Vz_url_mcp {

}

/* End of file mcp.vz_url.php */