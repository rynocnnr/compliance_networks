<?php

$lang = array(

// Field Settings

'vz_url_error_text'           => 'Указана некорректная ссылка',
'vz_url_redirect_text'        => 'Перенаправляет на',
'vz_url_redirect_update'      => 'Обновить',
'vz_url_nonlocal_text'        => 'Ссылка должна указывать на данный сайт',
'vz_url_open_text'            => 'Посетить страницу',

'field_preferences'           => 'Настройки поля',
'vz_url_show_redirects_label' => 'Уведомлять о редиректе по ссылке',
'vz_url_limit_local_label'    => 'Ограничить страницам данного сайта',
'yes'                         => 'Да',
'no'                          => 'Нет',

''=>''
);

/* End of file lang.vz_url.php */