<?php

$lang = array(

'vz_url_module_name'          => 'VZ URL',
'vz_url_module_description'   => 'Support file for VZ URL fieldtype',

// Field Settings

'vz_url_error_text'           => 'That URL appears to be invalid',
'vz_url_redirect_text'        => 'Redirects to',
'vz_url_redirect_update'      => 'Update',
'vz_url_nonlocal_text'        => 'Must be a URL on this website',
'vz_url_open_text'            => 'Visit URL',

'field_preferences'           => 'Field settings',
'vz_url_show_redirects_label' => 'Prompt to update redirected URLs',
'vz_url_limit_local_label'    => 'Limit to local URLs',
'yes'                         => 'Yes',
'no'                          => 'No',

''=>''
);

/* End of file lang.vz_url.php */